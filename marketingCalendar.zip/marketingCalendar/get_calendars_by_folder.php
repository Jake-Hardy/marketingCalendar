<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once 'functions/calendar_storage.php';

$folder = $_POST['folder'];

$calendars = getCalendarsByFolder($folder);
echo json_encode($calendars, JSON_FORCE_OBJECT);
?>
