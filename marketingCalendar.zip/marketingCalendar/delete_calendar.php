<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once 'functions/calendar_storage.php';

    $id = $_POST['id'];
    deleteCalendar($id);
?>
