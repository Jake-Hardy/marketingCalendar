<?php include 'view/header.php'; ?>
    <script>var page = 'calendar';</script>

    <div class="container closed">
        <!-- Class names that follow the BEM model (e.g., block--element__modifier)
             are used for CSS selectors, class names that use camelCase are JS
             hooks. Note: I have not done a very good job at sticking to this
             convention. -->
         <div class="calendar box__shadow clearfix">
             <div class="dateDiv">
                 <p class="card--calendar__text">Last edited:
                 <?php $date = date_create($calendar['lastEditedDate']); ?>
                 <?php echo date_format($date, "D, M jS, Y"); ?></span></p>
             </div>

			 <div class="folderDiv">
                 Folder: <?php echo ($calendar['Folder'] == '' ? 'No Folder': $calendar['Folder']); ?>
             </div>


        <?php if(isset($calendar)): ?>
            <?php $logo = $calendar['logo']; ?>
            <?php if ($logo != 'none') : ?>
                <img id="logo" class="logo" src=<?php echo $logo; ?> />
            <?php else: ?>
                <img id="logo" class="logo" src="http://sandbox.ocozzio.com/marketingCalendar/Logos/NoLogo.jpg" />
            <?php endif; ?>
            <div class="calendar--title box editable"><em class="calendar--title__text calendarTitle"><?php echo $calendar['Title']; ?></em></div>
        <?php else: ?>
            <img id="logo" class="logo" />
            <div class="calendar--title box editable"><em class="calendar--title__text calendarTitle">Calendar Title</em></div>
        <?php endif; ?>
        </div>
    </div>

    <div class="container--messages"><span class="messages"></span></div>

    <div class="error"><?php echo $errors; ?></div>

    <div class="container--calendar-options__shadowbox">
        <div class="container--calendar-options calendarOptions box">
            <div class="container--input__menu">
                <label>Number of Audiences</label>
                <input class="input__audience inputAudience" type="text" value=<?php if($calendar['Rows']) {echo ($calendar['Rows'] - 1);} else {echo '2';} ?> />
            </div>
            <div class="container--input__menu">
                <label>Number of Months</label>
                <br />
                <div class="flex--row">
                    <span>
                        <input class="input__months" type="radio"
                               name="months" value="3" <?php if ($calendar['Cols']==4) {echo 'checked';} ?>>3
                    </span>
                    <span>
                        <input class="input__months" type="radio"
                               name="months" value="6" <?php if ($calendar['Cols']==7) {echo 'checked';} ?>>6
                    </span>
                    <span>
                        <input class="input__months" type="radio"
                               name="months" value="9" <?php if ($calendar['Cols']==10) {echo 'checked';} ?>>9
                    </span>
                    <span>
                        <input class="input__months" type="radio"
                               name="months" value="12" <?php if ($calendar['Cols']==13) {echo 'checked';} ?>>12
                    </span>
                </div>
           </div>

		    <?php
				$calendar['logo'] = str_replace('http://sandbox.ocozzio.com/marketingCalendar/Logos/', '', $calendar['logo']);
				$calendar['logo'] = str_replace('.jpg', '', $calendar['logo']);
			?>
           <div class="conainer--input__menu">
               <select id="logoSelect" class="container--input__menu">
                   <option>Select Logo</option>
                   <option value="AHDI" <?php if ($calendar['logo'] == 'AHDI') { echo 'selected'; } ?> >AHDI</option>
                   <option value="Allegiance" <?php if ($calendar['logo'] == 'Allegiance') { echo 'selected'; } ?> >Allegiance</option>
                   <option value="AP" <?php if ($calendar['logo'] == 'AP') { echo 'selected'; } ?> >AmeraPlan</option>
                   <option value="ACOC" <?php if ($calendar['logo'] == 'ACOC') { echo 'selected'; } ?> >Augusta Chamber</option>
                   <option value="Avidia" <?php if ($calendar['logo'] == 'Avidia') { echo 'selected'; } ?> >Avidia</option>
                   <option value="AWP" <?php if ($calendar['logo'] == 'AWP') { echo 'selected'; } ?> >AWP</option>
                   <option value="BPA" <?php if ($calendar['logo'] == 'BPA') { echo 'selected'; } ?> >BPA</option>
                   <option value="Coeur" <?php if ($calendar['logo'] == 'Coeur') { echo 'selected'; } ?> >Coeur</option>
				   <option value="Copernicus" <?php if ($calendar['logo'] == 'Copernicus') { echo 'selected'; } ?> >Copernicus</option>
                   <option value="CS" <?php if ($calendar['logo'] == 'CS') { echo 'selected'; } ?> >CoreSource</option>
                   <option value="DHS" <?php if ($calendar['logo'] == 'DHS') { echo 'selected'; } ?> >DHS</option>
                   <option value="Echo" <?php if ($calendar['logo'] == 'Echo') { echo 'selected'; } ?> >Echo</option>
                   <option value="EHIM" <?php if ($calendar['logo'] == 'EHIM') { echo 'selected'; } ?> >EHIM</option>
                   <option value="ELAP" <?php if ($calendar['logo'] == 'ELAP') { echo 'selected'; } ?> >ELAP</option>
                   <option value="EP" <?php if ($calendar['logo'] == 'EP') { echo 'selected'; } ?> >EP</option>
                   <option value="EPB" <?php if ($calendar['logo'] == 'EPB') { echo 'selected'; } ?> >EPB</option>
                   <option value="Evolution" <?php if ($calendar['logo'] == 'Evolution') { echo 'selected'; } ?> >Evolution</option>
                   <option value="GPA" <?php if ($calendar['logo'] == 'GPA') { echo 'selected'; } ?> >GPA</option>
                   <option value="HCS" <?php if ($calendar['logo'] == 'HCS') { echo 'selected'; } ?> >HCS</option>
				   <option value="HSP" <?php if ($calendar['logo'] == 'HSP') { echo 'selected'; } ?> >HSP</option>
                   <option value="IHP" <?php if ($calendar['logo'] == 'IHP') { echo 'selected'; } ?> >IHP</option>
                   <option value="INM" <?php if ($calendar['logo'] == 'INM') { echo 'selected'; } ?> >INM</option>
                   <option value="KB" <?php if ($calendar['logo'] == 'KB') { echo 'selected'; } ?> >Kemper Benefits</option>
                   <option value="KRN" <?php if ($calendar['logo'] == 'KRN') { echo 'selected'; } ?> >Kemper Reserve</option>
                   <option value="KBA" <?php if ($calendar['logo'] == 'KBA') { echo 'selected'; } ?> >Key Benefit Administrators</option>
                   <option value="NHD" <?php if ($calendar['logo'] == 'NHD') { echo 'selected'; } ?> >NHD</option>
                   <option value="Nova" <?php if ($calendar['logo'] == 'Nova') { echo 'selected'; } ?> >Nova</option>
                   <option value="PMCS" <?php if ($calendar['logo'] == 'PMCS') { echo 'selected'; } ?> >PMCS</option>
                   <option value="TPSC" <?php if ($calendar['logo'] == 'TPSC') { echo 'selected'; } ?> >TPSC</option>
                   <option value="Xytex" <?php if ($calendar['logo'] == 'Xytex') { echo 'selected'; } ?> >Xytex</option>
               </select>
           </div>

           <div class="container--input__color">
               <div class="container--input__menu container--input__colors">
                   <label>Title Color</label>
                   <div class="container--input__color">
                       <label>R:</label>
                       <input id="red" class="color" type="range" min="0" max="255" step="1" value=<?php echo ($calendar['red'] !== 0 ? $calendar['red'] : 133); ?> />
                       <input id="rVal" type="number" min="0" max="255" step="1" value=<?php echo ($calendar['red'] !== 0 ? $calendar['red'] : 133); ?> />
                   </div>

                   <div class="container--input__color">
                       <label>G:</label>
                       <input id="green" class="color" type="range" min="0" max="255" step="1" value=<?php echo ($calendar['green'] !== 0 ? $calendar['green'] : 186); ?> />
                       <input id="gVal" type="number" min="0" max="255" step="1" value=<?php echo ($calendar['green'] !== 0 ? $calendar['green'] : 186); ?> />
                   </div>

                   <div class="container--input__color">
                       <label>B:</label>
                       <input id="blue" class="color" type="range" min="0" max="255" step="1" value=<?php echo ($calendar['blue'] !== 0 ? $calendar['blue'] : 57); ?> />
                       <input id="bVal" type="number" min="0" max="255" step="1" value=<?php echo ($calendar['blue'] !== 0 ? $calendar['blue'] : 57); ?> />
                   </div>
               </div>

               <div id="colorPreview" class="container--input__menu container--input__color-preview container--input__colors"></div>
           </div>

           <div class="container--input__menu">
               <input type="checkbox" id="showDate" checked />
               <label>Show date calendar was last edited</label>
           </div>

		   <div class="container--input__menu">
			   	<input type="checkbox" id="showFolder" checked />
				<label>Show folder calendar is saved to</label>
		   </div>

		   <div class="container--input__menu">
               <select id="folderSelect" class="container--input__menu">
                   <option value="">Select Folder</option>
				   <option value="AHDI" <?php if ($calendar['Folder'] == 'AHDI') { echo 'selected'; } ?> >AHDI</option>
                   <option value="Allegiance" <?php if ($calendar['Folder'] == 'Allegiance') { echo 'selected'; } ?> >Allegiance</option>
                   <option value="AP" <?php if ($calendar['Folder'] == 'AP') { echo 'selected'; } ?> >AmeraPlan</option>
                   <option value="ACOC" <?php if ($calendar['Folder'] == 'ACOC') { echo 'selected'; } ?> >Augusta Chamber</option>
                   <option value="Avidia" <?php if ($calendar['Folder'] == 'Avidia') { echo 'selected'; } ?> >Avidia</option>
                   <option value="AWP" <?php if ($calendar['Folder'] == 'AWP') { echo 'selected'; } ?> >AWP</option>
                   <option value="BPA" <?php if ($calendar['Folder'] == 'BPA') { echo 'selected'; } ?> >BPA</option>
                   <option value="Coeur" <?php if ($calendar['Folder'] == 'Coeur') { echo 'selected'; } ?> >Coeur</option>
                   <option value="CS" <?php if ($calendar['Folder'] == 'CS') { echo 'selected'; } ?> >CoreSource</option>
                   <option value="DHS" <?php if ($calendar['Folder'] == 'DHS') { echo 'selected'; } ?> >DHS</option>
                   <option value="Echo" <?php if ($calendar['Folder'] == 'Echo') { echo 'selected'; } ?> >Echo</option>
                   <option value="EHIM" <?php if ($calendar['Folder'] == 'EHIM') { echo 'selected'; } ?> >EHIM</option>
                   <option value="ELAP" <?php if ($calendar['Folder'] == 'ELAP') { echo 'selected'; } ?> >ELAP</option>
                   <option value="EP" <?php if ($calendar['Folder'] == 'EP') { echo 'selected'; } ?> >EP</option>
                   <option value="EPB" <?php if ($calendar['Folder'] == 'EPB') { echo 'selected'; } ?> >EPB</option>
                   <option value="Evolution" <?php if ($calendar['Folder'] == 'Evolution') { echo 'selected'; } ?> >Evolution</option>
                   <option value="GPA" <?php if ($calendar['Folder'] == 'GPA') { echo 'selected'; } ?> >GPA</option>
                   <option value="HCS" <?php if ($calendar['Folder'] == 'HCS') { echo 'selected'; } ?> >HCS</option>
                   <option value="IHP" <?php if ($calendar['Folder'] == 'IHP') { echo 'selected'; } ?> >IHP</option>
                   <option value="INM" <?php if ($calendar['Folder'] == 'INM') { echo 'selected'; } ?> >INM</option>
                   <option value="KB" <?php if ($calendar['Folder'] == 'KB') { echo 'selected'; } ?> >Kemper Benefits</option>
                   <option value="KRN" <?php if ($calendar['Folder'] == 'KRN') { echo 'selected'; } ?> >Kemper Reserve</option>
                   <option value="KBA" <?php if ($calendar['Folder'] == 'KBA') { echo 'selected'; } ?> >Key Benefit Administrators</option>
                   <option value="NHD" <?php if ($calendar['Folder'] == 'NHD') { echo 'selected'; } ?> >NHD</option>
                   <option value="Nova" <?php if ($calendar['Folder'] == 'Nova') { echo 'selected'; } ?> >Nova</option>
                   <option value="PMCS" <?php if ($calendar['Folder'] == 'PMCS') { echo 'selected'; } ?> >PMCS</option>
                   <option value="TPSC" <?php if ($calendar['Folder'] == 'TPSC') { echo 'selected'; } ?> >TPSC</option>
                   <option value="Xytex" <?php if ($calendar['Folder'] == 'Xytex') { echo 'selected'; } ?> >Xytex</option>
               </select>
           </div>

           <input class="button button--submit container--input__menu buttonSubmitOptions" type="submit" value="Generate">
           <div class="button--close buttonClose">
               X
           </div>
        </div>
    </div>

    <div class="container--form__login formLoginContainer box">
        <form class="formLogin" method="post" action=".">
            <label>Username</label>
            <input class="fieldUsername" type="text" name="username" />
            <input type="hidden" name="action" value="login" />
            <input type="hidden" name="prevAction" value=<?php echo $action; ?> />
            <a class="button button--submit buttonSubmitLogin">Submit</a>
            <p class="errorLogin"></p>
        </form>
        <span>Don't have an account yet? Click <a class="button" href="register.php">here</a> to register.</span>
        <div class="button--close buttonClose">
           X
        </div>
    </div>

    <script src="js/jquery-2.2.3.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.2.61/jspdf.debug.js"></script>
    <script src="js/html2canvas.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.debug.js"></script> -->
	<script src="js/cal.js"></script>
</body>
</html>
