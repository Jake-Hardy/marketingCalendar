<?php
require_once 'model/Database.class.php';
require_once 'functions/calendar_storage.php';
//require_once 'functions/users.functions.php';

session_start();

if(isset($_POST['action'])) {
    $action = $_POST['action'];
}

if(isset($_POST['id'])) {
    $id = $_POST['id'];
}

$folders = getFolders();

include './view/header.php';
?>

<script>var page = 'library';</script>

<div class="container--card" id="card">
    <?php foreach($folders as $folder) : ?>
		<?php $logo = (($folder['Folder'] == '') ? 'http://sandbox.ocozzio.com/marketingCalendar/Logos/NoLogo.jpg' : "http://sandbox.ocozzio.com/marketingCalendar/Logos/" . $folder['Folder'] . '.jpg'); ?>
        <div class="cardSpinner">
            <div class="card--calendar box box__shadow cardShrinker">
                <h4><?php echo ($folder['Folder'] == '') ? 'No Folder' : $folder['Folder']; ?></h4>
				<img id="logo" class="logo" <?php echo ($logo == '' ? '' : 'src="'.$logo.'"'); ?> />
                <form method="post" action="index.php">
                    <input type="hidden" name="folder" value=<?php echo $folder['Folder']; ?> />
                    <input class="button button--browse card--button buttonBrowseFolder" type="submit" value="BROWSE FOLDER" />
                </form>
            </div>
        </div>
    <?php endforeach; ?>
</div>


<div id="calHolder">

</div>

<div id="accordion">
	<?php foreach($folders as $folder) : ?>
		<?php $logo = (($folder['Folder'] == '') ? 'http://sandbox.ocozzio.com/marketingCalendar/Logos/NoLogo.jpg' : "http://sandbox.ocozzio.com/marketingCalendar/Logos/" . $folder['Folder'] . '.jpg'); ?>
		<div class="accordion--folder">
			<div class="accordion--folder__info">
				<img id="logo" class="logo--accordion" <?php echo ($logo == '' ? '' : 'src="'.$logo.'"'); ?> />
				<h4><?php echo ($folder['Folder'] == '') ? 'No Folder' : $folder['Folder']; ?></h4>
				<form method="post" action="index.php">
					<input type="hidden" name="folder" value=<?php echo $folder['Folder']; ?> />
				</form>
				<div class="arrow--accordion__container">
					<img class="arrow--accordion" src='http://sandbox.ocozzio.com/marketingCalendar/view/next.svg' />
				</div>
			</div>
		</div>
	<?php endforeach; ?>
</div>


<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/cal.js"></script>
<script src="js/selectJS.js"></script>
<script>
	$(document).ready(function() {
		$('#card').hide();
		$('#calHolder').hide();
	});

	$('#viewAccordion').on('click', function() {
		$('#card').hide();
		$('#calHolder').hide();
		$('#accordion').show();
	})

	$('#viewCard').on('click', function() {
		$('#card').show();
		$('#calHolder').show();
		$('#accordion').hide();
	})

    $('.buttonBrowseFolder').on('click', function(e) {
        $('#calHolder').children().remove();
        e.preventDefault();
		var name = $(this).parent().siblings('h4:first').text();
		name = (name === 'No Folder' ? '' : name);
        var folder = '{"folder": "' + name + '"}';
        console.log(folder);
		var that = $(this);
        $.ajax({
            type: 'POST',
            url: 'get_calendars_by_folder.php',
            data: JSON.parse(folder),
            success: function(response) {
                var calendars = JSON.parse(response);
                for (var cal in calendars) {
                    var card = '';
                    card += '<div class="cardSpinner">';
                    card += '<div class="card--calendar box box__shadow cardShrinker">';
                    card += '<div class="card--wrapper card--wrapper__details">';
                    card += '<h4 class="card--calendar__text card--header">'+calendars[cal].Title+'</h4>';
                    card += '<img id="logo" class="logo" src="' + (calendars[cal].logo === 'none' ? 'http://sandbox.ocozzio.com/marketingCalendar/Logos/NoLogo.jpg' : calendars[cal].logo) + '" />';
                    card += '</div>';
                    card += '<div class="card--wrapper">';
                    card += '<span class="card--calendar__text">Last edited: '+calendars[cal].lastEditedDate+'</span>';
                    card += '</div>';
                    card += '<div class="card--wrapper card--wrapper__button">';
                    card += '<form method="get" action="index.php">';
                    card += '<input type="hidden" name="id" class="idHook" value='+calendars[cal]['ID']+' />';
                    card += '<input type="hidden" name="action" value="edit" />';
                    card += '<input class="button button--edit card--button buttonEdit" type="submit" value="EDIT" />';
                    card += '</form>';
                    card += '<input type="hidden" name="id" class="idHook" value='+calendars[cal]['ID']+' />';
                    card += '<input type="hidden" name="action" value="delete" />';
                    card += '<input class="button button--edit card--button buttonDelete" type="submit" value="DELETE" />';
                    card += '</div></div></div>';

                    $('#calHolder').append(card);
                }
				$('.buttonDelete').on('click', function() {
			        var parent = $(this).parent();
			        var selection = '';
			        var modal = "<div id='confirmDelete' class='container--confirm-delete box'></div>"
			        $('body').append(modal);
			        $('#confirmDelete').append("<p>Delete this calendar?</p>");
			        $('#confirmDelete').append("<input class='button buttonConfirm confirmYes' value='YES' />");
			        $('#confirmDelete').append("<input class='button buttonConfirm confirmNo' value='NO' />");

			        $('.buttonConfirm').on("click", function() {
			            selection = $(this).val();
			            console.log(selection);

			            if (selection === 'YES') {
			                console.log(parent.children('.idHook').val());
			                $.ajax({
			                    type: 'POST',
			                    url:  'delete_calendar.php',
			                    data: {'id': parent.children('.idHook').val()},
			                    success: function(response) {
			                        $(parent).parent().remove();
			                        $('#confirmDelete').remove();
			                    }
			                });
			            }
			            else {
			                $('#confirmDelete').remove();
			            }
			        })
			    });
            }
        });
		//$(that).removeClass('.accordion--folder__grow');
	});

	$('.arrow--accordion').on('click', function() {
		$(this).toggleClass('arrow--accordion__rotate');
		$('.folder--grow').remove();

		var thisFolder = $(this).parent().parent().parent();

		var name = $(this).parent().siblings('h4:first').text();
		name = (name === 'No Folder' ? '' : name);
        var folder = '{"folder": "' + name + '"}';
		folder = JSON.parse(folder);
        console.log(folder);
		$(thisFolder).append('<div class="folder--grow"></div>');
		var folderGrow = $(thisFolder).children('.folder--grow');
		$(folderGrow).css('max-height', '2000px');
		if ($(this).hasClass('arrow--accordion__rotate')) {
			$.ajax({
	            type: 'POST',
	            url: 'get_calendars_by_folder.php',
	            data: folder,
	            success: function(response) {
	                var calendars = JSON.parse(response);
	                for (var cal in calendars) {
						var entry = '';
						entry += '<div class="accordion--entry">';
							entry += '<div class="accordion--info__container">';
								entry += '<span>' + calendars[cal].Title + '</span>&nbsp;-&nbsp;';
								entry += '<span>' + calendars[cal].lastEditedDate + '</span>';
							entry += '</div>';
							entry += '<div class="accordion--button__container">';
								entry += '<form class="accordion--button" method="get" action="index.php">';
									entry += '<input type="hidden" name="id" class="idHook" value=' + calendars[cal]['ID'] + ' />';
									entry += '<input type="hidden" name="action" value="edit" />';
									entry += '<input class="buttonEdit" type="submit" value="EDIT" />'
								entry += '</form>';
								//entry += '<form class="accordion--button">';
									entry += '<input type="hidden" name="id" class="idHook" value=' + calendars[cal]['ID'] + ' />';
									entry += '<input type="hidden" name="action" value="delete" />';
									entry += '<input class="buttonDelete" type="submit" value="DELETE" />';
								//entry += '</form>';
							entry += '</div>';
						entry += '</div>';
						$(folderGrow).append(entry);
	                }
					$('.buttonDelete').on('click', function() {
				        var parent = $(this).parent();
						var id = $(this).siblings('.idHook').val();
				        var selection = '';
				        var modal = "<div id='confirmDelete' class='container--confirm-delete box'></div>"
				        $('body').append(modal);
				        $('#confirmDelete').append("<p>Delete this calendar?</p>");
				        $('#confirmDelete').append("<input class='button buttonConfirm confirmYes' value='YES' />");
				        $('#confirmDelete').append("<input class='button buttonConfirm confirmNo' value='NO' />");

				        $('.buttonConfirm').on("click", function() {
				            selection = $(this).val();
				            console.log(selection);

				            if (selection === 'YES') {
				                console.log(id);
				                $.ajax({
				                    type: 'POST',
				                    url:  'delete_calendar.php',
				                    data: {'id': parent.children('.idHook').val()},
				                    success: function(response) {
				                        $(parent).parent().remove();
				                        $('#confirmDelete').remove();
				                    }
				                });
				            }
				            else {
				                $('#confirmDelete').remove();
				            }
				        })
				    });
	            }
	        });
		}

	})
</script>
<?php include './view/footer.php'; ?>
