<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once 'functions/calendar_storage.php';

    $calendarTitle = $_POST['title'];
    $calendarFolder = $_POST['folder'];
    $statement = tableExistsInFolder($calendarTitle, $calendarFolder);
    echo ($statement->rowCount() > 0)
?>
