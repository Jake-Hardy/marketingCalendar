# marketingCalendar
Redesign for the Marketing Calendar

Editable link for Calendars table spreadsheet: https://docs.google.com/spreadsheets/d/1R7_PvqHUMYwHn1U8ghpj6yi47pNkQycvN_InrHPX-9M/edit?usp=sharing
Editable link for Cells table spreadsheet: https://docs.google.com/spreadsheets/d/1nDmvngHzeKQBWaitPKT7Mwmioggnmg9FHch-WLiXbdM/edit?usp=sharing

# TODO
- ~~Start work on Load function.~~
- Start work on user account system.
