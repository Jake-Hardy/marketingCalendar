<?php

set_include_path(__DIR__);
$debug = true;
$app_path = "/calendarTest";

?>
