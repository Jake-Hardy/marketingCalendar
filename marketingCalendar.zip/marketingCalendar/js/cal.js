//global used in downloadCanvas()
//don't you judge me
count = 0;
saveCount = 0;

if (page === 'calendar') {
    setInterval(function() {save()}, (1000*60*2));
}





/*******************************************************************************
 * ready()                                                                     *
 *******************************************************************************/

$(document).ready(function() {
    $('.container--calendar-options__shadowbox').hide();
    $('.container--calendar-options').hide();
    $('.formLoginContainer').hide();

    if ($('.loadFlag').val() === "true") {
        loadCalendar();
    }

    changeColor();
});





/*******************************************************************************
 * Event Handlers                                                              *
 *******************************************************************************/

$(".buttonOptions").on("click", function() {
    $('.container--calendar-options__shadowbox').show();
    $('.container--calendar-options').show();
});

$('.buttonLogin').on("click", function() {
    $('.container--calendar-options__shadowbox').show();
    $('.formLoginContainer').show();
});

$('.buttonLogout').on("click", function() {
    $.ajax({
        type: 'POST',
        url:  'logout.php',
        success: function(response) {
            window.location.href="index.php?action=create-calendar"
        }
    });
});

$(".buttonSubmitOptions").on("click", function() {
    generateCalendar();
    $('.container--calendar-options__shadowbox').hide();
    $('.container--calendar-options').hide();
});

$('.buttonLoad').on('click', function() {
    if ($('.userHook').val() !== undefined) {
        window.location.href = 'select_calendar.php';
    }
    else {
        $('.errorLogin').text("You need to be logged in to do that.");
        $('.buttonLogin').click();
    }
});

$('.buttonSubmitLogin').on("click", function() {
    var username = $('.fieldUsername').val();
    $.ajax({
        type: 'POST',
        url:  'login.php',
        data: {'username' : username},
        success: function(response) {
            if (response === 'true') {
                $('.formLogin').submit();
            }
            else {
                $('.errorLogin').text(response);
            }
        }
    });
});

$(".input__audience").on("keydown", function(e) {
    if (e.keyCode === 13) {
        generateCalendar();
        toggleMenu();
    }
});

$('.menu__button').on("click", function() {
    toggleMenu();
});

$('.buttonSave').on("click", function() {
    if ($('.userHook').val() !== undefined) {
        checkForOverwrite();
    }
    else {
        $('.errorLogin').text("You need to be logged in to do that.");
        $('.buttonLogin').click();
    }
});

$('.buttonClose').on("click", function() {
    $('.container--calendar-options__shadowbox').hide();
    $(this).parent().hide();
});

$('#logoSelect').on("change", function() {
    var img = $(this).val();
    $("#logo").attr('src', 'http://sandbox.ocozzio.com/marketingCalendar/Logos/'+img+'.jpg');
});

$('.color').on('input', function() {
    changeColor();
});

$('#rVal, #gVal, #bVal').on('change', function() {
    var r = $('#rVal').val();
    $('#red').val(r);

    var g = $('#gVal').val();
    $('#green').val(g);

    var b = $('#bVal').val();
    $('#blue').val(b);

    $('#colorPreview').css('background-color', 'rgb('+r+','+g+','+b+')');
    $('.calendar--title').css('background-color', 'rgb('+r+','+g+','+b+')');
});

$("#showDate").on('click', function() {
    $('.dateDiv').toggle();
});

$('#showFolder').on('click', function() {
	$('.folderDiv').toggle();
});



$(".calendar").on("click", ".editable", function(e) {
    if($('.menu__fold-up').hasClass('open')) {
        toggleMenu();
    }

    if($(this).hasClass('editing')) {
        return;
    }

    var currentText = $(this).text();
    var textEntry = "<textarea class='textEntry input--text' wrap='hard' cols='25' spellcheck='true'></textarea>";
    $(this).children().hide();
    $(this).addClass("editing");
    $(this).append(textEntry);
    $(".textEntry").focus().val(currentText);
    var that = $(this);
    $(".textEntry").focusout(function(e) {
        that.children().text( $(".textEntry").val() );
        $(".textEntry").remove();
        that.removeClass("editing");
        that.children().show();
        if(!that.hasClass("calendar--title")) {
            checkHeight(that);
        }
    })
});

if (page === 'calendar') {
	// console.log(document.getElementById('export'));
    document.getElementById('export').addEventListener('click', function() {
		html2canvas($('.container'), {
			onrendered: function(canvas) {
				document.body.appendChild(canvas);
				var canvas = $('canvas')[0];
                $(canvas).attr('id', 'exportCanvas');

                downloadCanvas($('.calendarTitle').text() + '.png');
            }
        });
    }, false);
}






/*******************************************************************************
 * Functions                                                                   *
 *******************************************************************************/

function downloadCanvas(filename) {
    var canvas = $('canvas')[0];
    $(canvas).attr('id', 'exportCanvas');

    var imgData = canvas.toDataURL("image/png", 1.0);
	var pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'in'
    });
	// console.log('pdf: '+pdf);

    pdf.addImage(imgData, 'PNG', 0, 0, 11.75, 8.5);
    //pdf.addHTML(canvas);
    var download = document.getElementById('download');

	window.setTimeout(function() {
		pdf.save("download.pdf");
	}, 3000);


    // link = document.getElementById('export');
    // link.href = document.getElementById('exportCanvas').toDataURL();
    // link.download = filename;
    $('#exportCanvas').remove();
    // if (count < 1) {
    //     window.setTimeout(function() {
    //         count++;
    //         link.click();
    //     }, 1000);
    // }
}

function changeColor() {
    var r = $('#red').val();
    $('#rVal').val(r);

    var g = $('#green').val();
    $('#gVal').val(g);

    var b = $('#blue').val();
    $('#bVal').val(b);

    $('#colorPreview').css('background-color', 'rgb('+r+','+g+','+b+')');
    $('.calendar--title').css('background-color', 'rgb('+r+','+g+','+b+')');
}

function buildColorCoding(rows) {
    for(var i = 0; i <= rows; i++) {
        var color = '';
        switch(i % 5) {
            case 0:
                color = '#292383';
                break;
            case 1:
                color = '#23A73A';
                break;
            case 2:
                color =  '#D0211C';
                break;
            case 3:
                color = '#292585';
                break;
            case 4:
                color =  '#D2281D';
                break;
        }
        $('.calendar div[class*="row_"]:nth-child(' + (i + 5) + ') div[class*="cell_"] p').css('color', color);
    }
}

function toggleMenu() {
    $('.container').toggleClass('open');
    $('.container').toggleClass('closed');

    $('.menu__fold-up').toggleClass('closed');
    $('.menu__fold-up').toggleClass('open');
    if($('.menu__fold-up').hasClass('closed')) {
        $('.inputAudience').hide('slow');
    }
    else {
        $('.inputAudience').show('slow');
    }

    $('.menu__button').toggleClass('menu__closed');
    $('.menu__button').toggleClass('menu__open');
}

function checkHeight(cell) {
    var height = cell.css("height");
    //console.log(height);
    cell.siblings().css("height", height);
}

function generateCalendar() {
    var calendar = saveCells();

    $("div[class*=row_]").remove();

    calendar.audienceCount = $(".input__audience").val();
    // console.log("audienceCount: " + calendar.audienceCount);
    var i, j;
    for (i = 0; i <= calendar.audienceCount; i++) {
        if (i === 0) {
            var newRow = "<div class='row_header row_" + i + "'></div>";
            var currentRow = ".row_header";
        }
        else {
            var newRow = "<div class='row_" + i + "'></div>";
            var currentRow = ".row_" + i;
        }

        $(".calendar").append(newRow);
        $(currentRow).addClass("clearfix");
        var numCells = $('input[name=months]:checked').val();
        for (j = 0; j <= numCells; j++) {
            if (j === 0 || i === 0) {
                if (calendar['.cell_'+i+'_'+j]) {
                    var newCell="<div class='col_header cell_"+i+"_"+j+" editable'><p class='col_header--text'>"+calendar['.cell_'+i+'_'+j].content+"</p></div>"
                }
                else {
                    var newCell = "<div class='col_header cell_" + i + "_" + j + " editable'><p class='col_header--text'></p></div>";
                }
            }
            else {
                if (calendar['.cell_'+i+'_'+j]) {
                    var newCell = "<div class='cell_" + i + "_" + j + " editable'><p>"+calendar['.cell_'+i+'_'+j].content+"</p></div>";
                }
                else {
                    var newCell = "<div class='cell_" + i + "_" + j + " editable'><p></p></div>";
                }
            }
            var currentCell = ".cell_" + i + "_" + j;
            $(currentRow).append(newCell);
            $(currentCell).addClass("box");
            $(currentCell).addClass('cells' + numCells);
        }
    }
    $("div[class*=row_]").hide();
    $("div[class*=row_]").show(1000, "linear");
    //console.log(calendar);
    var count = 0;
    $.each(calendar, function(k, cell) {
        if (count > 4) {
            checkHeight( $(k) );
            // console.log(k);
        }
        count++;
        var currentCell = '.cell_'+cell.Row+'_'+cell.Col;

        //checkHeight($(currentCell));
        // $.each(cell, function(k, v) {
        //     // var currentCell = '.cell_'+cell.Row+'_'+cell.Col;
        //     // checkHeight($(currentCell));
        // });
    });

    buildColorCoding(i);
}

function saveCells() {
    var rows = $('div[class*=row_]').length;
    var cols = parseInt($('input[name=months]:checked').val());
    var logo = $('#logo').attr('src');
    if (!logo) {
        logo = '';
    }
    var folder = $('#folderSelect').val();
    var r = $('#rVal').val();
    var g = $('#gVal').val();
    var b = $('#bVal').val();

    var calendar = {
        "rows" : rows,
        "cols" : cols+1,
        "logo" : logo,
        "folder": folder,
        "red": r,
        "green": g,
        "blue": b
    };
    calendar["title"] = $('.calendarTitle').text();
    calendar['owner'] = $('.userHook').val();
    var i, j;
    for(i = 0; i < rows; i++) {
        for(j = 0; j <= cols; j++) {
            var key = '.cell_' + i + '_' + j;
            var value = $(key).text();
            calendar[key] = { "row" : i, "col" : j, "content" : value };
        }
    }

    return calendar;
}

function checkForOverwrite() {
    var calendar = saveCells();
    if (saveCount > 0) {
        return save();
    }

    $.ajax({
        type: 'POST',
        url: 'check_calendar_title.php',
        data: {'title': calendar.title, 'folder': calendar.folder},
        success: function(response) {
            if (response === '1') {
                var shadowBox = $('<div id="overWriteShadowBox" class="container--calendar-options__shadowbox"></div>');
                var modal = $(
                    '<div id="overwriteModal" class="container--calendar-options calendarOptions box">' +
                        '<h4>A calendar named "' + calendar.title + '" already exists in folder "' + calendar.folder +'". Saving the current calendar will overwrite the existing one.</h4>' +
                        '<h4>Continue?</h4>' +
                        '<input type="submit" id="overwriteYes" value="Yes" class="button button--submit buttonOverwrite" />' +
                        '<input type="submit" id="overwriteNo" value="No" class="button button--submit buttonOverwrite" />' +
                    '</div>');

                $(shadowBox).append(modal);
                $('body').append(shadowBox);

                $('.buttonOverwrite').on('click', function(e) {
                    if ($(this).val() === 'No') {
                        $(shadowBox).remove();
                        return;
                    }
                    else {
                        count++;
                        $(shadowBox).remove();
                        save();
                    }
                });
            }
            else {
                return save();
            }
        }
    });
}

function save() {
    var calendar = saveCells();
    $.ajax({
        type: 'POST',
        url:  'save_calendar.php',
        data: calendar,
        success: function(response) {
            $('.error').append(response);
            $('.container--messages').css('left', '30vw');
            $('.messages').text("Save successful");
            window.setTimeout(function() {
                $('.container--messages').css('left', '-100%');
            }, 3000);
        }
    });
}

function loadCalendar() {
    var cells;
    $("div[class*=row_]").remove();
    if($('.loadFlag').val() === "true") {
        id = $('.idHook').val();
		// url = window.location.href;
		// console.log(url);
		// window.history.pushState("objecet or string", "Title", url + '?id=' + id);

        var audienceCount;

        $.ajax({
            url : "load_calendar.php",
            method : "get",
            data : "id=" + id,
            success : function(data){
                result = $.parseJSON(data);
                calendarInfo = result[0];
                cells = result[1];
                // console.log('test');
                // console.log("Cells: " + cells);
                // console.log("Rows: " + calendarInfo['Rows']);
                audienceCount = calendarInfo['Rows'];

                $('.calendar--title').children().hide();
                $('.calendar--title').children().text(calendarInfo['Title']);
                $('.calendar--title').children().show();

                for (i = 0; i < audienceCount; i++) {
                    var newRow = "<div class='row_"+i+"'></div>";
                    var currentRow = ".row_"+i;
                    $('.calendar').append(newRow);
                    if (i === 0) {
                        $(currentRow).addClass('row_header');
                    }
                    $(currentRow).addClass('clearfix');

                    // Evil ahead. for...in can bite my bird
                    for (var cell in cells) {
                        var row = parseInt(cells[cell]['Row']);
                        if (row === i) {
                            var newCell = "<div class='cell_"+cells[cell]['Row']+"_"+cells[cell]['Col']+" editable'><p>"+cells[cell]['Content']+"</p></div>";
                            var currentCell = ".cell_"+cells[cell]['Row']+"_"+cells[cell]['Col'];
                            $(currentRow).append(newCell);
                            if (cells[cell]['Row'] === "0" || cells[cell]['Col'] === "0") {
                                $(currentCell).addClass("col_header");
                                $(currentCell).children('p').addClass('col_header--text');
                            }
                            if (calendarInfo['Cols'] === "4") {
                                $(currentCell).addClass("cells3");
                            }
                            else if (calendarInfo['Cols'] === "7") {
                                $(currentCell).addClass("cells6");
                            }
                            else if (calendarInfo['Cols'] === "10") {
                                $(currentCell).addClass("cells9");
                            }
                            else {
                                $(currentCell).addClass("cells12");
                            }
                            $(currentCell).addClass('box');

                        }
                    }
                }
                $("div[class*=row_]").hide();
                $("div[class*=row_]").show(1000, "linear");

                buildColorCoding(i);

                $.each(cells, function(k, cell) {
                    var currentCell = '.cell_'+cell.Row+'_'+cell.Col;
                    checkHeight($(currentCell));
                    $.each(cell, function(k, v) {
                        // var currentCell = '.cell_'+cell.Row+'_'+cell.Col;
                        // checkHeight($(currentCell));
                    });
                });
            }
        });
    }
}
